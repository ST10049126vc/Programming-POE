/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//POE 
//Refrencing List

//Adapted from https://javahungry.blogspot.com/2020/06/check-string-contains-special-characters.html 
//JavaHungry 
//2022 

//Adapted from https://stackoverflow.com/questions/66499432/javascript-first-name-input-and-last-name-input-then-greet-the-user-with-welc 
//stackoverflow 
//2021 

//Adapted from https://1bestcsharp.blogspot.com/2019/03/java-login-and-register-form.html 
//1bestCsharp Blog 
//2019 

//Adapted from https://www.javacodeexamples.com/check-password-strength-in-java-example/668 
//Rahim V 
//2019 

//Adapted from https://www.youtube.com/watch?v=3vauM7axnRs 
//1bestCsharp Blog 
//2019 

//Adapted from https://www.tutorialsfield.com/login-form-in-java-swing-with-source-code/ 
//Mehtab Hameed 
//2018 

//Adapted from https://www.youtube.com/watch?v=54yGDNLjzro 
//Pritam Thing 
//2018 
package programmingpoe;
//declaring variables
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author DISD3
 */
public class ProgrammingPOE {
  //-----------Begin-----------//  
static String username, password, firstName, lastName;
    //main method
    public static void main(String[] args) {

      //declarations
        int errorCode = 0;
        //using JOptionPane to get users first name
        firstName = JOptionPane.showInputDialog(null, "Enter your first name");
        //using JOptionPane to get users last name
        lastName = JOptionPane.showInputDialog(null, "Enter your last name");
        username = JOptionPane.showInputDialog(null, "Enter a username");
        //using JOptionPane to get users username
        boolean validUsername = checkUserName();
        if (validUsername == false) {
            errorCode = 1;
            registerUser(errorCode);
        }
        //using JOptionPane to get users password
        password = JOptionPane.showInputDialog(null, "Enter a password");
        boolean validPassword = checkPasswordComplexity();
        if (validPassword == false) {
            errorCode = 2;
            registerUser(errorCode);
        }
        if (validPassword && validUsername) {
            JOptionPane.showMessageDialog(null, "Welcome to easyKanban");

            JOptionPane.showMessageDialog(null, "Welcome " + firstName + ", " + lastName + " it is great to see you");
        } else {
            JOptionPane.showMessageDialog(null, "There was an error");
        }

        boolean login = loginUser();
        JOptionPane.showMessageDialog(null, returnLoginStatus(login));
        if (login) {
            String userChoice = "";
            boolean exit = false;
            boolean Description = false;
            double totalTime = 0;
            while (exit == false) {
                userChoice = JOptionPane.showInputDialog("Enter 1 to add tasks\nEnter 2 to view report\nEnter 3 to quit");
                if (userChoice.equals("1")) {
                    int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Please enter the number of tasks that you are adding today"));
                    String[] tasks = new String[numTasks];
                    for (int i = 0; i < numTasks; i++) {
                        String taskName = JOptionPane.showInputDialog("Please enter the name of the task");
                        int taskNum = i;
                        String taskDescription = "";
                        while (Description == false)
                        //yo ensure the users description is less than 50 characters
                        {
                            taskDescription = JOptionPane.showInputDialog("Please enter a description of the task in less than 50 characters");
                            if (taskDescription.length() < 50) {
                                Description = true;
                            }
                        }
                        String developerDetails = JOptionPane.showInputDialog("Please enter the developers details");
                        double taskDuration = Double.parseDouble(JOptionPane.showInputDialog("Please enter the duration of the task"));
                        String taskID = taskName.substring(0, 2).toUpperCase() + ":" + taskNum + ":" + developerDetails.substring(developerDetails.length() - 3).toUpperCase();
                        String taskStatus = JOptionPane.showInputDialog("Please enter the status of the task\nIt can only be: To-do, Doing, Done");
                        totalTime = totalTime + taskDuration;
                        String task = "Task Status: " + taskStatus + "\nDeveloper Details: " + developerDetails + "\nTask Number: " + taskNum + "\nTask Name: " + taskName + "\nTask Description: " + taskDescription + "\nTask ID: " + taskID + "\nTask Duration: " + taskDuration + " Hours";
                        JOptionPane.showMessageDialog(null, task);
                        tasks[i] = task;
                    }
                    JOptionPane.showMessageDialog(null, "There is a total of " + totalTime + " hours on record for the tasks");
                }
                if (userChoice.equals("2")) {
                    JOptionPane.showMessageDialog(null, "Coming soon");
                }
                if (userChoice.equals("3")) {
                    JOptionPane.showMessageDialog(null, "Thank you for using our application");
                    exit = true;
                }
            }
        }
    }
    //using if to ensure the username contains an underscore and is less than 5 characters
    public static boolean checkUserName() {
        boolean valid = false;
        if (username.contains("_") && username.length() <= 5) {
            JOptionPane.showMessageDialog(null, "Username Successfully captured");
            valid = true;
        }
        return valid;
    }

    public static boolean checkPasswordComplexity() {
        boolean length = false;
        boolean special = false;
        boolean capital = false;
        boolean number = false;
        boolean valid = false;
        //using if to ensure the password is less than 8 characters
        if (password.length() >= 8) {
            length = true;
        }

        for (int p = 0; p < password.length(); p++) {
            if (Character.isUpperCase(password.charAt(p))) {
                capital = true;
            }
        }

        Pattern pattern2 = Pattern.compile("[^a-z|A-Z|0-9]");
        Matcher matcher2 = pattern2.matcher(password);
        boolean matchFound2 = matcher2.find();
        if (matchFound2) {
            special = true;
        }
        for (int d = 0; d < password.length(); d++) {
            if (Character.isDigit(password.charAt(d))) {
                number = true;
            }
        }
        //using if to ensure the password has a special character, number and capital
        if (length && special && number && capital) {
            JOptionPane.showMessageDialog(null, "Password successfully captured");
            valid = true;
        }
        return valid;
    }

    public static void registerUser(int code) {
        if (code == 1) {
            JOptionPane.showMessageDialog(null, "The username is not correctly formatted. Please ensure that the username is no more than 5 charachters long and contains an underscore");
        }
        if (code == 2) {
            JOptionPane.showMessageDialog(null, "The password is not correctly formatted. Please ensure that the password is no less than 8 characters long, contains a number, contains a capital, and contains a special charachter");
        }
    }

    public static boolean loginUser() {
        String newUser = JOptionPane.showInputDialog("Please enter the username");
        String newPass = JOptionPane.showInputDialog("Please enter the password");
        boolean validLogin = false;
        if (newUser.equals(username) && newPass.equals(password)) {
            validLogin = true;
        }
        return validLogin;
    }

    public static String returnLoginStatus(boolean validLogin) {
        String output = "";
        //using if to return the output if everything is entred c0rrectly
        if (validLogin) {

            output = "Welcome back " + firstName + ", " + lastName + " it is great to see you again";
        } else {
            output = "There was an error";
        }

        return output;
    }
    //start of POE 3
    if (opt == 2) {
    ArrayList mikeSmith = new ArrayList();
mikeSmith.add("Mike Smith");
mikeSmith.add("Create login");
mikeSmith.add(5);
mikeSmith.add("To Do");

ArrayList edwardHarrison = new ArrayList();
edwardHarrison.add("Edward Harrison");
edwardHarrison.add("Create add features");
edwardHarrison.add(8);
edwardHarrison.add("Doing");

ArrayList samanthaPaulson = new ArrayList();
samanthaPaulson.add("Samantha Paulson");
samanthaPaulson.add("Create reports");
samanthaPaulson.add(2);
samanthaPaulson.add("Done");

ArrayList glendaOberholzer = new ArrayList();
glendaOberholzer.add("Glenda Oberholzer");
glendaOberholzer.add("Add Arrays");
glendaOberholzer.add(11);
glendaOberholzer.add("To do");

//Choosing the option
int option = Integer.parseInt(JOptionPane.showInputDialog(null, " Please choose an Option \n"+
"1. Display Tasks \n"+
"2. Search \n"+
"3. Delete a task \n"+
"4. Quit"));

switch (option)
{
case 1: 
//displays the tasks
int displayChoice = Integer.parseInt(JOptionPane.showInputDialog(null, "1. Display all tasks \n"+
"2. Display longest task \n"+
"3. Display tasks that are done"));

switch (option) {
case 1:

JOptionPane.showMessageDialog(null, mikeSmith + "\n" +
edwardHarrison + "\n" +
samanthaPaulson + "\n" +
glendaOberholzer);
break;

case 2: 

int num1 = (int) mikeSmith.get(2);
int num2 = (int) edwardHarrison.get(2);
int num3 = (int) samanthaPaulson.get(2);
int num4 = (int) glendaOberholzer.get(2);
int[] hours = {num1, num2, num3, num4};

int largest = hours[0];

for (int i = 0; i < hours.length; i++) {
if (hours[i] > largest) {
largest = hours[i];
}
}
//displays the longest task
if (mikeSmith.contains(largest)) {
JOptionPane.showMessageDialog(null, "The longest task is" + mikeSmith.get(0) +", "+ mikeSmith.get(2) +" hours", "Longest Task", JOptionPane.INFORMATION_MESSAGE);
} else if (edwardHarrison.contains(largest)) {
JOptionPane.showMessageDialog(null, "The longest task is " + edwardHarrison.get(0) +", "+ edwardHarrison.get(2) +" hours", "Longest Task", JOptionPane.INFORMATION_MESSAGE);
} else if (samanthaPaulson.contains(largest)) {
JOptionPane.showMessageDialog(null, "The longest task is " + samanthaPaulson.get(0) +", "+ samanthaPaulson.get(2) +" hours", "Longest Task", JOptionPane.INFORMATION_MESSAGE);
} else if (glendaOberholzer.contains(largest)) {
JOptionPane.showMessageDialog(null, "The longest task is " + glendaOberholzer.get(0) +", "+ glendaOberholzer.get(2) +" hours", "Longest Task", JOptionPane.INFORMATION_MESSAGE);
}

break;

case 3: //tasks done

if (mikeSmith.contains("Done"))
{
JOptionPane.showMessageDialog(null, "These following tasks are done: " + mikeSmith.get(0) +", "+ mikeSmith.get(1) +", "+ mikeSmith.get(2) +" hours");
}
else if (edwardHarrison.contains("Done"))
{
JOptionPane.showMessageDialog(null, "These following tasks are done: " + edwardHarrison.get(0) +", "+ edwardHarrison.get(1) +", "+ edwardHarrison.get(2) +" hours");
}
else if (samanthaPaulson.contains("Done"))
{
JOptionPane.showMessageDialog(null, "These following tasks are done: " + samanthaPaulson.get(0) +", "+ samanthaPaulson.get(1) +", "+ samanthaPaulson.get(2) +" hours");
}
else if (glendaOberholzer.contains("Done"))
{
JOptionPane.showMessageDialog(null, "These following tasks are done: " + glendaOberholzer.get(0) +", "+ glendaOberholzer.get(1) +", "+ glendaOberholzer.get(2) +" hours");
}
else
{
JOptionPane.showMessageDialog(null, "No tasks are done" );
}

break;
}
break;


case 2:

String search = JOptionPane.showInputDialog("Please enter the task name or developer");

if(search.equalsIgnoreCase("Create login") || search.equalsIgnoreCase("Mike Smith"))
{
JOptionPane.showMessageDialog(null,"Search result: " + mikeSmith.get(1) +", "+ mikeSmith.get(0) +", "+ mikeSmith.get(3));
}
else if (search.equalsIgnoreCase("Create add features") || search.equalsIgnoreCase("Edward Harrison"))
{
JOptionPane.showMessageDialog(null, "Search result: " + edwardHarrison.get(1) +", "+ edwardHarrison.get(0) +", "+ edwardHarrison.get(3));
}
else if (search.equalsIgnoreCase("Create reports") || search.equalsIgnoreCase("Samantha Paulson"))
{
JOptionPane.showMessageDialog(null, "Search result: " + samanthaPaulson.get(1) +", "+ samanthaPaulson.get(0) +", "+ samanthaPaulson.get(3));
}
else if (search.equalsIgnoreCase("Add Arrays") || search.equalsIgnoreCase("Glenda Oberholzer"))
{
JOptionPane.showMessageDialog(null, "Search result: " +glendaOberholzer.get(1) +", "+ glendaOberholzer.get(0) +", "+ glendaOberholzer.get(3));
}
else
{
JOptionPane.showMessageDialog(null, "That task or developer does not exist", "Error", JOptionPane.ERROR_MESSAGE);
}

break;

case 3:
    //enter the tasks that need to be deleted

String delete = JOptionPane.showInputDialog(null, "enter the task you would like to delete");
if(delete.equalsIgnoreCase("Create login"))
{
mikeSmith.clear();
JOptionPane.showMessageDialog(null, mikeSmith +"\n"+
edwardHarrison +"\n"+
samanthaPaulson +"\n"+
glendaOberholzer);
}

else if (delete.equalsIgnoreCase("Create add features"))
{
edwardHarrison.clear();
JOptionPane.showMessageDialog(null, mikeSmith +"\n"+
edwardHarrison +"\n"+
samanthaPaulson +"\n"+
glendaOberholzer);
}
else if (delete.equalsIgnoreCase("Create reports"))
{
samanthaPaulson.clear();
JOptionPane.showMessageDialog(null, mikeSmith +"\n"+
edwardHarrison +"\n"+
samanthaPaulson +"\n"+
glendaOberholzer);
}
else if (delete.equalsIgnoreCase("Add Arrays"))
{
glendaOberholzer.clear();
JOptionPane.showMessageDialog(null, mikeSmith +"\n"+
edwardHarrison +"\n"+
samanthaPaulson +"\n"+
glendaOberholzer);
}

//displays the tasks that dont exist
else
{
JOptionPane.showMessageDialog(null, "that task does not exist", "Error", JOptionPane.ERROR_MESSAGE);
}
break;
}

}
  


//-----------End----------//

    /**
     * @param args the command line arguments
     */
    
        // TODO code application logic here
    
    

